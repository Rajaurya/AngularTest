import { GalleryComponent } from './gallery/gallery.component';
import { ContactComponent } from './contact/contact.component';
import { ComponentsComponent } from './components/components.component';
import { BlogComponent } from './blog/blog.component';
import { BlogDetailComponent } from './blog-detail/blog-detail.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ServicesComponent } from './services/services.component';
import { FeaturesComponent } from './features/features.component';


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';

const routes: Routes = [
                    
                    {path:'gallery',component:GalleryComponent},
                    {path:'Aboutus',component:AboutUsComponent},
                    {path:'Services',component:ServicesComponent},
                    {path:'features',component:FeaturesComponent},
                    {path:'component',component:ComponentsComponent},
                    {path:'Blog',component:BlogComponent},
                    {path:'BlogDetails',component:BlogDetailComponent},
                    {path:'Contact',component:ContactComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
